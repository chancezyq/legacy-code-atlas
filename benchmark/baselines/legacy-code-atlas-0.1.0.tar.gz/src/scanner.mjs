import { open, readFile, readdir, stat } from "node:fs/promises";
import path from "node:path";

const DEFAULT_IGNORED_DIRECTORIES = new Set([
  ".git",
  ".hg",
  ".svn",
  ".idea",
  ".legacy-code-atlas",
  ".vscode",
  "build",
  "dist",
  "node_modules",
  "out",
  "target",
  "vendor",
]);

const FILE_TYPES = new Map([
  [".java", ["java", "code"]],
  [".jsp", ["jsp", "markup"]],
  [".jspx", ["jsp", "markup"]],
  [".js", ["javascript", "code"]],
  [".mjs", ["javascript", "code"]],
  [".html", ["html", "markup"]],
  [".htm", ["html", "markup"]],
  [".xml", ["xml", "config"]],
  [".properties", ["properties", "config"]],
  [".sql", ["sql", "data"]],
  [".md", ["markdown", "docs"]],
  [".txt", ["text", "docs"]],
]);

function toPosix(value) {
  return value.split(path.sep).join("/");
}

function globToRegExp(pattern) {
  let expression = "^";
  for (let index = 0; index < pattern.length; index += 1) {
    const character = pattern[index];
    if (character === "*" && pattern[index + 1] === "*") {
      expression += ".*";
      index += 1;
    } else if (character === "*") {
      expression += "[^/]*";
    } else if (character === "?") {
      expression += "[^/]";
    } else {
      expression += character.replace(/[|\\{}()[\]^$+?.]/g, "\\$&");
    }
  }
  return new RegExp(`${expression}$`);
}

async function isBinary(absolutePath, size) {
  if (size === 0) return false;
  const handle = await open(absolutePath, "r");
  try {
    const sample = Buffer.alloc(Math.min(size, 8192));
    const { bytesRead } = await handle.read(sample, 0, sample.length, 0);
    return sample.subarray(0, bytesRead).includes(0);
  } finally {
    await handle.close();
  }
}

export async function scanProject(projectRoot, options = {}) {
  const root = path.resolve(projectRoot);
  const maxFileBytes = options.maxFileBytes ?? 5 * 1024 * 1024;
  let projectIgnores = [];
  try {
    projectIgnores = (await readFile(path.join(root, ".legacy-code-atlasignore"), "utf8"))
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith("#"));
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  const ignoreMatchers = [...projectIgnores, ...(options.ignore ?? [])].map(globToRegExp);
  const files = [];
  const skipped = [];

  const ignored = (relativePath) => ignoreMatchers.some((matcher) => matcher.test(relativePath));

  async function walk(absoluteDirectory, relativeDirectory = "") {
    const entries = await readdir(absoluteDirectory, { withFileTypes: true });
    entries.sort((left, right) => left.name.localeCompare(right.name, "en"));

    for (const entry of entries) {
      const relativePath = toPosix(path.join(relativeDirectory, entry.name));
      const absolutePath = path.join(absoluteDirectory, entry.name);

      if (entry.isSymbolicLink()) {
        skipped.push({ path: relativePath, reason: "symbolic-link" });
        continue;
      }
      if (entry.isDirectory()) {
        if (DEFAULT_IGNORED_DIRECTORIES.has(entry.name) || ignored(`${relativePath}/`)) continue;
        await walk(absolutePath, relativePath);
        continue;
      }
      if (!entry.isFile() || ignored(relativePath)) continue;

      const extension = path.extname(entry.name).toLowerCase();
      const type = FILE_TYPES.get(extension);
      if (!type) {
        skipped.push({ path: relativePath, reason: "unsupported-file-type" });
        continue;
      }

      const metadata = await stat(absolutePath);
      if (metadata.size > maxFileBytes) {
        skipped.push({ path: relativePath, reason: "file-too-large", size: metadata.size });
        continue;
      }
      if (await isBinary(absolutePath, metadata.size)) {
        skipped.push({ path: relativePath, reason: "binary-file" });
        continue;
      }

      files.push({
        path: relativePath,
        absolutePath,
        language: type[0],
        category: type[1],
        size: metadata.size,
      });
    }
  }

  await walk(root);
  files.sort((left, right) => left.path.localeCompare(right.path, "en"));
  skipped.sort((left, right) => left.path.localeCompare(right.path, "en"));

  return { root, files, skipped };
}
