import { evidenceAt } from "../evidence.mjs";
import { findXmlElements, findXmlText, withoutXmlComments, xmlStructureWarnings } from "./xml-utils.mjs";

function strutsUrl(path) {
  if (!path) return "";
  return /\.[a-z0-9]+$/i.test(path) ? path : `${path}.do`;
}

export function parseWebXml(content, filePath) {
  const source = withoutXmlComments(content);
  const servlets = findXmlElements(source, "servlet", filePath)
    .map((element) => ({
      name: findXmlText(element.inner, "servlet-name"),
      className: findXmlText(element.inner, "servlet-class"),
      evidence: element.evidence,
    }))
    .filter((servlet) => servlet.name && servlet.className);
  const classByName = new Map(servlets.map((servlet) => [servlet.name, servlet.className]));
  const routes = [];
  for (const mapping of findXmlElements(source, "servlet-mapping", filePath)) {
    const servletName = findXmlText(mapping.inner, "servlet-name");
    const urlPattern = findXmlText(mapping.inner, "url-pattern");
    if (!servletName || !urlPattern) continue;
    routes.push({
      url: urlPattern,
      servletName,
      targetClass: classByName.get(servletName) ?? "",
      source: "servlet",
      evidence: mapping.evidence,
    });
  }
  return { servlets, routes, warnings: xmlStructureWarnings(content, filePath, "web-app") };
}

export function parseStrutsConfig(content, filePath) {
  const source = withoutXmlComments(content);
  const actions = [];
  for (const element of findXmlElements(source, "action", filePath)) {
    const { path, type, name: formName = "", parameter = "" } = element.attributes;
    if (!path || !type) continue;
    const forwards = findXmlElements(element.inner, "forward", filePath).map((forward) => ({
      name: forward.attributes.name ?? "",
      path: forward.attributes.path ?? "",
      evidence: evidenceAt(source, filePath, element.offset + element.raw.indexOf(forward.raw), forward.raw.length),
    }));
    actions.push({
      path,
      url: strutsUrl(path),
      type,
      formName,
      parameter,
      forwards,
      evidence: element.evidence,
    });
  }
  return { actions, warnings: xmlStructureWarnings(content, filePath, "struts-config") };
}

export function parseSpringConfig(content, filePath) {
  const source = withoutXmlComments(content);
  const beanElements = findXmlElements(source, "bean", filePath);
  const beans = beanElements
    .map((element) => ({
      id: element.attributes.id ?? element.attributes.name ?? "",
      className: element.attributes.class ?? "",
      evidence: element.evidence,
    }))
    .filter((bean) => bean.id && bean.className);
  const classById = new Map(beans.map((bean) => [bean.id, bean.className]));
  const routes = [];
  for (const handler of beanElements.filter((element) => /(?:^|\.)SimpleUrlHandlerMapping$/.test(element.attributes.class ?? ""))) {
    for (const property of findXmlElements(handler.inner, "property", filePath).filter((element) => element.attributes.name === "mappings")) {
      for (const match of property.inner.matchAll(/<prop\b[^>]*\bkey\s*=\s*(["'])(.*?)\1[^>]*>([\s\S]*?)<\/prop\s*>/gi)) {
        const url = match[2].trim();
        const beanId = match[3].replace(/<[^>]+>/g, "").trim();
        if (!url.startsWith("/") || !beanId) continue;
        const absoluteOffset = handler.offset + handler.raw.indexOf(match[0]);
        routes.push({
          url,
          beanId,
          targetClass: classById.get(beanId) ?? "",
          source: "spring-simple-url",
          evidence: evidenceAt(source, filePath, absoluteOffset, match[0].length),
          offset: absoluteOffset,
        });
      }
      for (const entry of findXmlElements(property.inner, "entry", filePath)) {
        const url = entry.attributes.key ?? entry.attributes["key-ref"] ?? "";
        const beanId = entry.attributes["value-ref"] ?? entry.attributes.value ?? "";
        if (!url.startsWith("/") || !beanId) continue;
        const absoluteOffset = handler.offset + handler.raw.indexOf(entry.raw);
        routes.push({
          url,
          beanId,
          targetClass: classById.get(beanId) ?? "",
          source: "spring-simple-url",
          evidence: evidenceAt(source, filePath, absoluteOffset, entry.raw.length),
          offset: absoluteOffset,
        });
      }
    }
  }
  routes.sort((left, right) => left.offset - right.offset);
  return {
    beans,
    routes: routes.map(({ offset: _offset, ...route }) => route),
    warnings: xmlStructureWarnings(content, filePath, "beans"),
  };
}
