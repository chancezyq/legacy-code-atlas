function simpleName(typeName) {
  return String(typeName ?? "").replace(/<.*>/g, "").split(".").at(-1);
}

function candidatesForType(indexes, typeName, context = null) {
  if (!typeName) return [];
  const direct = indexes.typesByFull.get(typeName);
  if (direct) return direct;
  const simple = simpleName(typeName);
  if (context) {
    const explicitImport = context.imports?.find((importName) => importName.endsWith(`.${simple}`));
    if (explicitImport && indexes.typesByFull.has(explicitImport)) return indexes.typesByFull.get(explicitImport);
    const samePackage = context.packageName ? `${context.packageName}.${simple}` : "";
    if (samePackage && indexes.typesByFull.has(samePackage)) return indexes.typesByFull.get(samePackage);
    const wildcardPrefixes = (context.imports ?? []).filter((importName) => importName.endsWith(".*")).map((importName) => importName.slice(0, -2));
    const wildcardMatches = (indexes.typesBySimple.get(simple) ?? []).filter((record) => wildcardPrefixes.some((prefix) => record.fullName.startsWith(`${prefix}.`)));
    if (wildcardMatches.length) return wildcardMatches;
  }
  return indexes.typesBySimple.get(simple) ?? [];
}

function methodsNamed(indexes, typeId, methodName) {
  return (indexes.methodsByType.get(typeId) ?? []).filter((method) => method.name === methodName);
}

function routeMatches(pattern, url) {
  if (pattern === url) return true;
  if (pattern === "/*") return url.startsWith("/");
  if (pattern.endsWith("/*")) return url.startsWith(pattern.slice(0, -1));
  return false;
}

export function resolveFacts(graph, facts) {
  const indexes = {
    typesByFull: new Map(),
    typesBySimple: new Map(),
    methodsByType: new Map(),
    statementsByFull: new Map(),
    statementsByShort: new Map(),
  };

  for (const javaFile of facts.javaFiles) {
    for (const typeRecord of javaFile.types) {
      indexes.typesByFull.set(typeRecord.fullName, [typeRecord]);
      const simple = indexes.typesBySimple.get(typeRecord.name) ?? [];
      simple.push(typeRecord);
      indexes.typesBySimple.set(typeRecord.name, simple);
      indexes.methodsByType.set(typeRecord.node.id, typeRecord.methods);
    }
  }
  for (const statement of facts.statements) {
    indexes.statementsByFull.set(statement.fullId, statement);
    const short = indexes.statementsByShort.get(statement.id) ?? [];
    short.push(statement);
    indexes.statementsByShort.set(statement.id, short);
  }

  for (const routeTarget of facts.routeTargets) {
    const mappedRoutes = [...graph.nodes.values()].filter(
      (node) => node.type === "route" && routeMatches(routeTarget.routeNode.name, node.name),
    );
    const targetTypes = candidatesForType(indexes, routeTarget.targetClass);
    if (targetTypes.length === 0) {
      graph.addWarning(`unresolved route target: ${routeTarget.routeNode.name} -> ${routeTarget.targetClass}`);
    }
    for (const targetType of targetTypes) {
      for (const mappedRoute of mappedRoutes) {
        graph.addEdge({
          source: mappedRoute.id,
          target: targetType.node.id,
          type: "maps_to",
          confidence: targetType.fullName === routeTarget.targetClass ? 1 : 0.8,
          reason: routeTarget.source,
          evidence: [routeTarget.evidence, ...mappedRoute.evidence, ...targetType.node.evidence],
        });
        const hints = mappedRoute.data.requestHints ?? [];
        const requestedMethods = routeTarget.dispatchParameter
          ? hints.map((hint) => hint.parameters?.[routeTarget.dispatchParameter]).filter((value) => value && !value.includes("${"))
          : [];
        let entryNames = [...new Set(requestedMethods)];
        let dispatchReason = routeTarget.dispatchParameter ? `Struts parameter ${routeTarget.dispatchParameter}` : "";
        if (entryNames.length === 0 && routeTarget.source === "servlet") {
          entryNames = [...new Set(hints.map((hint) => hint.method === "POST" ? "doPost" : hint.method === "GET" ? "doGet" : "service"))];
          dispatchReason = "Servlet HTTP method";
        }
        if (entryNames.length === 0 && /Spring/i.test(routeTarget.source)) {
          entryNames = ["handleRequest", "handleRequestInternal"];
          dispatchReason = "Spring legacy controller convention";
        }
        if (entryNames.length === 0 && !/DispatchAction$/.test(targetType.extendsType)) {
          entryNames = ["execute", "perform"];
          dispatchReason = "Action entry convention";
        }
        const entryMethods = entryNames.flatMap((name) => methodsNamed(indexes, targetType.node.id, name));
        for (const entryMethod of entryMethods) {
          graph.addEdge({
            source: mappedRoute.id,
            target: entryMethod.node.id,
            type: "dispatches_to",
            confidence: requestedMethods.includes(entryMethod.name) ? 1 : 0.9,
            reason: dispatchReason,
            evidence: [routeTarget.evidence, ...mappedRoute.evidence, ...entryMethod.node.evidence],
          });
        }
        if (entryMethods.length === 0) {
          graph.addWarning(`unresolved route entry: ${mappedRoute.name} -> ${targetType.fullName}`);
        }
      }
    }
  }

  for (const javaFile of facts.javaFiles) {
    for (const implementation of javaFile.types) {
      for (const declaredInterface of implementation.implementsTypes) {
        const contracts = candidatesForType(indexes, declaredInterface, javaFile);
        for (const contract of contracts) {
          const relationConfidence = contracts.length === 1 ? 1 : 0.5;
          const relationReason = contracts.length === 1 ? "Java implements declaration" : "ambiguous simple-name implements declaration";
          graph.addEdge({
            source: implementation.node.id,
            target: contract.node.id,
            type: "implements",
            confidence: relationConfidence,
            reason: relationReason,
            evidence: [...implementation.node.evidence, ...contract.node.evidence],
          });
          graph.addEdge({
            source: contract.node.id,
            target: implementation.node.id,
            type: "implemented_by",
            confidence: relationConfidence,
            reason: relationReason,
            evidence: [...implementation.node.evidence, ...contract.node.evidence],
          });
          for (const contractMethod of contract.methods) {
            for (const implementationMethod of methodsNamed(indexes, implementation.node.id, contractMethod.name)) {
              if (contractMethod.arity !== implementationMethod.arity) continue;
              graph.addEdge({
                source: contractMethod.node.id,
                target: implementationMethod.node.id,
                type: "implemented_by",
                confidence: relationConfidence,
                reason: contracts.length === 1 ? "interface method implementation" : "ambiguous interface method implementation",
                evidence: [...contractMethod.node.evidence, ...implementationMethod.node.evidence],
              });
            }
          }
        }
      }
    }
  }

  const allMethods = facts.javaFiles.flatMap((javaFile) => javaFile.types.flatMap((type) => type.methods));
  for (const javaFile of facts.javaFiles) {
    for (const ownerType of javaFile.types) {
      const fieldsByName = new Map(
        javaFile.fields.filter((field) => field.ownerType === ownerType.fullName).map((field) => [field.name, field.type]),
      );
      for (const call of javaFile.calls.filter((candidate) => candidate.ownerType === ownerType.fullName)) {
        const sourceMethods = ownerType.methods.filter((method) => method.name === call.enclosingMethod);
        const receiverName = call.receiver.split(".").at(-1);
        const receiverType = fieldsByName.get(receiverName);
        let targets = receiverType
          ? candidatesForType(indexes, receiverType, javaFile).flatMap((type) => methodsNamed(indexes, type.node.id, call.method))
          : [];
        let confidence = 0.9;
        let reason = receiverType ? `receiver field type ${receiverType}` : "";
        if (targets.length === 0) {
          const sameName = allMethods.filter((method) => method.name === call.method);
          if (sameName.length === 1) {
            targets = sameName;
            confidence = 0.5;
            reason = "unique method-name heuristic";
          }
        }
        for (const sourceMethod of sourceMethods) {
          for (const targetMethod of targets) {
            if (sourceMethod.node.id === targetMethod.node.id) continue;
            graph.addEdge({
              source: sourceMethod.node.id,
              target: targetMethod.node.id,
              type: "calls",
              confidence,
              reason,
              evidence: [call.evidence, ...targetMethod.node.evidence],
            });
          }
        }
      }

      for (const statementUse of javaFile.statementUses.filter((candidate) => candidate.ownerType === ownerType.fullName)) {
        const sourceMethods = ownerType.methods.filter((method) => method.name === statementUse.enclosingMethod);
        const exact = indexes.statementsByFull.get(statementUse.statementId);
        const candidates = exact ? [exact] : indexes.statementsByShort.get(statementUse.statementId) ?? [];
        if (candidates.length === 0) {
          graph.addWarning(`unresolved iBATIS statement: ${statementUse.statementId} at ${statementUse.evidence.file}:${statementUse.evidence.line}`);
        }
        for (const sourceMethod of sourceMethods) {
          sourceMethod.node.searchText = [...new Set([
            ...(sourceMethod.node.searchText ?? []),
            statementUse.statementId,
            statementUse.operation,
          ])];
          for (const statement of candidates) {
            const resolutionConfidence = statementUse.confidence ?? 1;
            const identifierConfidence = exact ? 1 : candidates.length === 1 ? 0.8 : 0.5;
            graph.addEdge({
              source: sourceMethod.node.id,
              target: statement.node.id,
              type: "uses_statement",
              confidence: Math.min(resolutionConfidence, identifierConfidence),
              reason: `${statementUse.resolution ?? "literal"} statement id via ${statementUse.operation}`,
              evidence: [statementUse.evidence, ...statement.node.evidence],
              data: { operation: statementUse.operation },
            });
          }
        }
      }
    }
  }

  return graph;
}
