export function normalizePath(filePath) {
  return String(filePath).replaceAll("\\", "/").replace(/^\.\//, "");
}

export function createEvidence(file, line, column = 1, snippet = "") {
  if (!Number.isInteger(line) || line < 1) throw new TypeError("evidence line must be a positive integer");
  if (!Number.isInteger(column) || column < 1) throw new TypeError("evidence column must be a positive integer");
  return {
    file: normalizePath(file),
    line,
    column,
    snippet: String(snippet).trim(),
  };
}

export function evidenceAt(content, file, offset, length = 0) {
  const prefix = content.slice(0, offset);
  const line = prefix.split("\n").length;
  const lastNewline = prefix.lastIndexOf("\n");
  const column = offset - lastNewline;
  const lineStart = lastNewline + 1;
  const nextNewline = content.indexOf("\n", offset);
  const lineEnd = nextNewline === -1 ? content.length : nextNewline;
  return createEvidence(file, line, column, content.slice(lineStart, lineEnd));
}
