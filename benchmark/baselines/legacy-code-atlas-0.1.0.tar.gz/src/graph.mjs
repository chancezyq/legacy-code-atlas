import { normalizePath } from "./evidence.mjs";

function normalizeKey(key) {
  return normalizePath(String(key).trim());
}

function normalizeEvidence(evidence = []) {
  return evidence.map((entry) => ({ ...entry, file: normalizePath(entry.file) }));
}

function countBy(items, field) {
  const counts = {};
  for (const item of items) counts[item[field]] = (counts[item[field]] ?? 0) + 1;
  return Object.fromEntries(Object.entries(counts).sort(([left], [right]) => left.localeCompare(right, "en")));
}

export class GraphBuilder {
  constructor({ projectRoot, warnings = [] }) {
    this.projectRoot = projectRoot;
    this.warnings = [...warnings];
    this.nodes = new Map();
    this.edges = new Map();
  }

  addWarning(warning) {
    this.warnings.push(String(warning));
  }

  addNode({ type, key, name, filePath, evidence = [], data = {}, searchText = [] }) {
    if (!type || key === undefined || key === null) throw new TypeError("node type and key are required");
    const normalizedKey = normalizeKey(key);
    const id = `${type}:${normalizedKey}`;
    const incoming = {
      id,
      type,
      name: String(name ?? normalizedKey),
      ...(filePath ? { filePath: normalizePath(filePath) } : {}),
      evidence: normalizeEvidence(evidence),
      data,
      searchText: [...new Set(searchText.map(String))],
    };
    const existing = this.nodes.get(id);
    if (!existing) {
      this.nodes.set(id, incoming);
      return incoming;
    }

    existing.evidence = [...existing.evidence, ...incoming.evidence].filter(
      (entry, index, all) => all.findIndex((candidate) => JSON.stringify(candidate) === JSON.stringify(entry)) === index,
    );
    existing.searchText = [...new Set([...existing.searchText, ...incoming.searchText])];
    existing.data = { ...existing.data, ...incoming.data };
    if (!existing.filePath && incoming.filePath) existing.filePath = incoming.filePath;
    return existing;
  }

  addEdge({ source, target, type, confidence, reason = "", evidence = [], data = {} }) {
    if (!this.nodes.has(source)) throw new Error(`unknown source node: ${source}`);
    if (!this.nodes.has(target)) throw new Error(`unknown target node: ${target}`);
    if (typeof confidence !== "number" || confidence < 0 || confidence > 1) {
      throw new TypeError("edge confidence must be between 0 and 1");
    }
    const id = `${source}|${type}|${target}|${reason}`;
    const edge = {
      id,
      source,
      target,
      type,
      confidence,
      reason,
      evidence: normalizeEvidence(evidence),
      data,
    };
    if (!this.edges.has(id)) this.edges.set(id, edge);
    return this.edges.get(id);
  }

  toJSON() {
    const nodes = [...this.nodes.values()].sort((left, right) => left.id.localeCompare(right.id, "en"));
    const edges = [...this.edges.values()].sort((left, right) => left.id.localeCompare(right.id, "en"));
    return {
      schemaVersion: "1.0.0",
      project: { root: this.projectRoot },
      summary: {
        nodes: nodes.length,
        edges: edges.length,
        nodeTypes: countBy(nodes, "type"),
        edgeTypes: countBy(edges, "type"),
      },
      nodes,
      edges,
      warnings: [...new Set(this.warnings)].sort((left, right) => left.localeCompare(right, "en")),
    };
  }
}

export function serializeGraph(graph) {
  return `${JSON.stringify(graph, null, 2)}\n`;
}
