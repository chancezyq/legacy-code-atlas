import { readFile } from "node:fs/promises";
import path from "node:path";

import { GraphBuilder } from "./graph.mjs";
import { parseIbatisSqlMap } from "./parsers/ibatis.mjs";
import { parseJava } from "./parsers/java.mjs";
import { extractJavaScriptRequests, normalizeRequestUrl, parseJsp, webPathForFile } from "./parsers/jsp.mjs";
import { parseSpringConfig, parseStrutsConfig, parseWebXml } from "./parsers/web-config.mjs";
import { resolveFacts } from "./resolver.mjs";
import { scanProject } from "./scanner.mjs";

function fileNode(graph, file) {
  return graph.addNode({
    type: "file",
    key: file.path,
    name: path.posix.basename(file.path),
    filePath: file.path,
    data: { language: file.language, category: file.category },
    searchText: [file.path, file.language],
  });
}

function addParserWarnings(graph, warnings = []) {
  for (const warning of warnings) graph.addWarning(warning);
}

function addRoute(graph, file, ownerNode, request, edgeType) {
  const route = graph.addNode({
    type: "route",
    key: request.url,
    name: request.url,
    evidence: [request.evidence],
    searchText: [request.url, request.kind ?? request.source ?? ""],
  });
  if (request.method || request.parameters) {
    const hint = {
      method: request.method ?? "",
      parameters: request.parameters ?? {},
      evidence: request.evidence,
    };
    const hints = route.data.requestHints ?? [];
    if (!hints.some((candidate) => JSON.stringify(candidate) === JSON.stringify(hint))) {
      route.data.requestHints = [...hints, hint];
    }
  }
  graph.addEdge({
    source: ownerNode.id,
    target: route.id,
    type: edgeType,
    confidence: 1,
    reason: request.kind ? `${request.kind} request` : request.source,
    evidence: [request.evidence],
  });
  return route;
}

function methodRecord(graph, type, method) {
  const arity = method.parameters.length;
  const node = graph.addNode({
    type: "java_method",
    key: `${type.fullName}#${method.name}/${arity}`,
    name: `${type.name}.${method.name}`,
    filePath: type.node.filePath,
    evidence: [method.evidence],
    data: { owner: type.fullName, method: method.name, arity, parameters: method.parameters, returnType: method.returnType },
    searchText: [type.fullName, type.name, method.name, ...method.parameters],
  });
  graph.addEdge({
    source: type.node.id,
    target: node.id,
    type: "declares",
    confidence: 1,
    reason: "Java method declaration",
    evidence: [method.evidence],
  });
  return { ...method, arity, node };
}

export async function analyzeProject(projectRoot, options = {}) {
  const scan = await scanProject(projectRoot, options);
  const graph = new GraphBuilder({ projectRoot: scan.root });
  for (const skipped of scan.skipped) {
    if (["file-too-large", "binary-file", "symbolic-link"].includes(skipped.reason)) {
      graph.addWarning(`skipped ${skipped.reason}: ${skipped.path}`);
    }
  }
  const facts = { javaFiles: [], routeTargets: [], statements: [] };
  const pageFileByWebPath = new Map(
    scan.files.filter((file) => file.language === "jsp").map((file) => [webPathForFile(file.path), file.path]),
  );
  const sourceFileByWebPath = new Map(
    scan.files.filter((file) => ["jsp", "javascript"].includes(file.language)).map((file) => [webPathForFile(file.path), file]),
  );

  for (const file of scan.files) {
    const content = await readFile(file.absolutePath, "utf8");
    const sourceFile = fileNode(graph, file);

    if (file.language === "jsp") {
      const parsed = parseJsp(content, file.path);
      addParserWarnings(graph, parsed.warnings);
      const page = graph.addNode({
        type: "page",
        key: file.path,
        name: path.posix.basename(file.path),
        filePath: file.path,
        evidence: parsed.textEntries.map((entry) => entry.evidence),
        searchText: [file.path, parsed.visibleText, ...parsed.textEntries.map((entry) => entry.text), ...parsed.fields.map((field) => field.name)],
        data: { visibleText: parsed.visibleText, fields: parsed.fields.map((field) => field.name) },
      });
      graph.addEdge({ source: sourceFile.id, target: page.id, type: "contains", confidence: 1, reason: "JSP page" });
      for (const request of parsed.requests) {
        const edgeType = request.kind === "form" ? "submits_to" : request.kind === "link" ? "links_to" : "requests";
        addRoute(graph, file, page, request, edgeType);
      }
      for (const include of parsed.includes) {
        const includeWebPath = normalizeRequestUrl(include.path, webPathForFile(file.path));
        const realPagePath = pageFileByWebPath.get(includeWebPath) ?? "";
        const includedPage = graph.addNode({
          type: "page",
          key: realPagePath || includeWebPath.replace(/^\//, ""),
          name: realPagePath ? path.posix.basename(realPagePath) : include.path,
          ...(realPagePath ? { filePath: realPagePath } : {}),
          evidence: [include.evidence],
          searchText: [include.path, realPagePath],
        });
        graph.addEdge({
          source: page.id,
          target: includedPage.id,
          type: "includes",
          confidence: 1,
          reason: "JSP include",
          evidence: [include.evidence],
        });
      }
      for (const script of parsed.scripts) {
        const targetFile = sourceFileByWebPath.get(script.path);
        if (!targetFile) {
          graph.addWarning(`unresolved JSP script: ${script.path} at ${script.evidence.file}:${script.evidence.line}`);
          continue;
        }
        const scriptFile = fileNode(graph, targetFile);
        graph.addEdge({
          source: page.id,
          target: scriptFile.id,
          type: "loads_script",
          confidence: 1,
          reason: "JSP script src",
          evidence: [script.evidence],
        });
      }
      continue;
    }

    if (file.language === "javascript") {
      for (const request of extractJavaScriptRequests(content, file.path)) addRoute(graph, file, sourceFile, request, "requests");
      continue;
    }

    if (file.language === "java") {
      const parsed = parseJava(content, file.path);
      addParserWarnings(graph, parsed.warnings);
      const typeRecords = parsed.types.map((type) => {
        const node = graph.addNode({
          type: "java_type",
          key: type.fullName,
          name: type.name,
          filePath: file.path,
          evidence: [type.evidence],
          data: { kind: type.kind, packageName: parsed.packageName, extendsType: type.extendsType, implementsTypes: type.implementsTypes },
          searchText: [file.path, type.name, type.fullName, type.extendsType, ...type.implementsTypes],
        });
        graph.addEdge({ source: sourceFile.id, target: node.id, type: "contains", confidence: 1, reason: "Java type" });
        const record = { ...type, node, methods: [] };
        record.methods = parsed.methods
          .filter((method) => method.ownerType === type.fullName)
          .map((method) => methodRecord(graph, record, method));
        return record;
      });
      facts.javaFiles.push({ ...parsed, file, sourceFile, types: typeRecords });
      continue;
    }

    if (file.language !== "xml") continue;
    if (/<sqlMap(?=\s|>)/i.test(content)) {
      const parsed = parseIbatisSqlMap(content, file.path);
      addParserWarnings(graph, parsed.warnings);
      for (const statement of parsed.statements) {
        const node = graph.addNode({
          type: "statement",
          key: statement.fullId,
          name: statement.fullId,
          filePath: file.path,
          evidence: [statement.evidence],
          data: { ...statement, evidence: undefined },
          searchText: [file.path, statement.id, statement.fullId, statement.type, statement.sql, ...statement.reads, ...statement.writes],
        });
        graph.addEdge({ source: sourceFile.id, target: node.id, type: "contains", confidence: 1, reason: "iBATIS statement" });
        const record = { ...statement, node };
        facts.statements.push(record);
        for (const tableName of statement.reads) {
          const table = graph.addNode({ type: "table", key: tableName, name: tableName, evidence: [statement.evidence], searchText: [tableName] });
          graph.addEdge({ source: node.id, target: table.id, type: "reads_from", confidence: 1, reason: "SQL FROM/JOIN", evidence: [statement.evidence] });
        }
        for (const tableName of statement.writes) {
          const table = graph.addNode({ type: "table", key: tableName, name: tableName, evidence: [statement.evidence], searchText: [tableName] });
          graph.addEdge({ source: node.id, target: table.id, type: "writes_to", confidence: 1, reason: `SQL ${statement.type}`, evidence: [statement.evidence] });
        }
      }
    }

    if (/<web-app(?=\s|>)/i.test(content)) {
      const parsed = parseWebXml(content, file.path);
      addParserWarnings(graph, parsed.warnings);
      for (const routeFact of parsed.routes) {
        const routeNode = addRoute(graph, file, sourceFile, { ...routeFact, kind: routeFact.source }, "contains");
        facts.routeTargets.push({ ...routeFact, routeNode });
      }
    }
    if (/<struts-config(?=\s|>)/i.test(content)) {
      const parsed = parseStrutsConfig(content, file.path);
      addParserWarnings(graph, parsed.warnings);
      for (const action of parsed.actions) {
        const routeNode = addRoute(graph, file, sourceFile, { url: action.url, evidence: action.evidence, source: "Struts action", kind: "struts" }, "contains");
        facts.routeTargets.push({
          routeNode,
          targetClass: action.type,
          source: "Struts action mapping",
          evidence: action.evidence,
          dispatchParameter: action.parameter,
        });
        for (const forward of action.forwards) {
          const forwardWebPath = normalizeRequestUrl(forward.path);
          const realPagePath = pageFileByWebPath.get(forwardWebPath) ?? "";
          const page = graph.addNode({
            type: "page",
            key: realPagePath || forwardWebPath.replace(/^\//, ""),
            name: realPagePath ? path.posix.basename(realPagePath) : forward.path,
            ...(realPagePath ? { filePath: realPagePath } : {}),
            evidence: [forward.evidence],
            searchText: [forward.name, forward.path, realPagePath],
          });
          graph.addEdge({ source: routeNode.id, target: page.id, type: "forwards_to", confidence: 1, reason: `Struts forward ${forward.name}`, evidence: [forward.evidence] });
        }
      }
    }
    if (/<beans(?=\s|>)/i.test(content)) {
      const parsed = parseSpringConfig(content, file.path);
      addParserWarnings(graph, parsed.warnings);
      for (const bean of parsed.beans) {
        const beanNode = graph.addNode({ type: "spring_bean", key: bean.id, name: bean.id, filePath: file.path, evidence: [bean.evidence], data: { className: bean.className }, searchText: [bean.id, bean.className] });
        graph.addEdge({ source: sourceFile.id, target: beanNode.id, type: "contains", confidence: 1, reason: "Spring bean" });
      }
      for (const routeFact of parsed.routes) {
        const routeNode = addRoute(graph, file, sourceFile, { ...routeFact, kind: routeFact.source }, "contains");
        facts.routeTargets.push({ ...routeFact, routeNode, source: "Spring SimpleUrlHandlerMapping" });
      }
    }
  }

  resolveFacts(graph, facts);
  return graph.toJSON();
}
